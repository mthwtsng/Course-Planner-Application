package ca.courseplanner.model;

/**
 * Model Class representing each Course Offering
 * Each Course Offering object contains a semester object
 */

public class CourseOffering {
    private static int nextId = 1;
    private Semester semester;
    private long semesterCode;
    private String location;
    private int enrolmentCapacity;
    private int enrolmentTotal;
    private String instructors;
    private String componentCode;
    private int courseOfferingId;

    public CourseOffering(String semester, String location, int enrolmentCapacity,
                          int enrolmentTotal, String instructors, String componentCode) {
        this.semester = new Semester(semester);
        this.semesterCode = Long.parseLong(semester);
        this.location = location;
        this.enrolmentCapacity = enrolmentCapacity;
        this.enrolmentTotal = enrolmentTotal;
        this.instructors = instructors;
        this.componentCode = componentCode;
        this.courseOfferingId = nextId++;
    }

    public Semester getSemester() {
        return semester;
    }

    public long getSemesterCode(){
        return semesterCode;
    }
    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getEnrolmentCapacity() {
        return enrolmentCapacity;
    }

    public void setEnrolmentCapacity(int enrolmentCapacity) {
        this.enrolmentCapacity = enrolmentCapacity;
    }

    public int getEnrolmentTotal() {
        return enrolmentTotal;
    }

    public void setEnrolmentTotal(int enrolmentTotal) {
        this.enrolmentTotal = enrolmentTotal;
    }

    public String getInstructors() {
        return instructors;
    }

    public void setInstructors(String instructors) {
        this.instructors = instructors;
    }

    public String getComponentCode() {
        return componentCode;
    }

    public void setComponentCode(String componentCode) {
        this.componentCode = componentCode;
    }
    public int getCourseOfferingId(){
        return courseOfferingId;
    }

}
