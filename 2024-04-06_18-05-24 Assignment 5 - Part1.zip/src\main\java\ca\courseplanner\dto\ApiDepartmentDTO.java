package ca.courseplanner.dto;

public class ApiDepartmentDTO {
    public long deptId;
    public String name;
}
