package ca.courseplanner.service;

import ca.courseplanner.dto.*;
import ca.courseplanner.model.Course;
import ca.courseplanner.model.CourseOffering;
import ca.courseplanner.model.Department;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Service class to handle course planning related logic and operations
 */

@Service
public class CoursePlannerService {
    private List<Department> departments = new ArrayList<>();

    public void addCourse(String subject, String catalogNumber, CourseOffering courseOffering) {
        Department department = findDepartmentByName(subject);
        if (department == null) {
            department = new Department(subject);
            departments.add(department);
        }
        Course existingCourse = department.findCourseBySubjectAndCatalogNumber(subject, catalogNumber);
        if (existingCourse != null) {
            existingCourse.addCourseComponent(courseOffering);
        } else {
            Course newCourse = new Course(subject, catalogNumber);
            newCourse.addCourseComponent(courseOffering);
            department.addCourse(newCourse);
        }
    }
    public List<Department> getAllDepartments() {
        return departments;
    }
    private Department findDepartmentByName(String name) {
        for (Department department : departments) {
            if (department.getDepartmentName().equals(name)) {
                return department;
            }
        }
        return null;
    }

    public void sortCourses() {
        departments.sort(Comparator.comparing(Department::getDepartmentName));
        for (Department department : departments) {
            department.sortCourses();
            for (Course course : department.getCourses()) {
                course.getAllCourseOfferings().sort(
                        Comparator.comparing(CourseOffering::getSemesterCode)
                                .thenComparing(CourseOffering::getLocation)
                                .thenComparing(CourseOffering::getInstructors)
                                .thenComparing(CourseOffering::getComponentCode)
                );
            }
        }
    }

    public void dumpModel() {
        for (Department department : departments) {
            for (Course course : department.getCourses()) {
                System.out.println(course.getSubject() + " " + course.getCatalogNumber());
                printCourseOfferings(course);
            }
        }
    }

    private void printCourseOfferings(Course course) {
        String currentSemesterLocation = "";
        String currentType = "";
        int totalEnrollment = 0;
        int totalCapacity = 0;
        for (CourseOffering component : course.getAllCourseOfferings()) {
            String semesterLocation = component.getSemesterCode() + " IN " + component.getLocation() + " BY " + component.getInstructors();
            if (!semesterLocation.equals(currentSemesterLocation)) {
                if (!currentSemesterLocation.isEmpty()) {
                    printComponent(currentType, totalEnrollment, totalCapacity);
                }
                System.out.println("    " + semesterLocation);
                currentSemesterLocation = semesterLocation;
                currentType = "";
                totalEnrollment = 0;
                totalCapacity = 0;
            }
            if (!currentType.equals(component.getComponentCode())) {
                if (!currentType.isEmpty()) {
                    printComponent(currentType, totalEnrollment, totalCapacity);
                    totalEnrollment = 0;
                    totalCapacity = 0;
                }
                currentType = component.getComponentCode();
            }
            totalEnrollment += component.getEnrolmentTotal();
            totalCapacity += component.getEnrolmentCapacity();
        }
        if (!currentSemesterLocation.isEmpty()) {
            printComponent(currentType, totalEnrollment, totalCapacity);
        }
    }

    private void printComponent(String currentType, int totalEnrollment, int totalCapacity) {
        System.out.println("        Type=" + currentType + ", Enrollment=" +
                totalEnrollment + "/" + totalCapacity);
    }

    public List<ApiDepartmentDTO> getAllDepartmentsAsDTO(){
        return departmentsToDto();
    }

    public List<ApiCourseDTO> getCoursesByDepartment(int deptId){
        return coursesToDto(findDepartmentById(deptId).getCourses());
    }

    public List<ApiCourseOfferingDTO> getCourseOfferings(int deptId, int courseId) {
        Department department = findDepartmentById(deptId);
        if (department != null) {
            Course course = findCourseById(department, courseId);
            if (course != null) {
                return courseOfferingToDTOS(course.getAllCourseOfferings());
            }
        }
        return null;
    }

    public List<ApiOfferingSectionDTO> getOfferingDetails(int deptId, int courseId, int offeringId) {
        Department department = findDepartmentById(deptId);
        if (department != null) {
            Course course = findCourseById(department, courseId);
            if (course != null) {
                CourseOffering offering = findCourseOfferingById(course, offeringId);
                if (offering != null) {
                    List<ApiOfferingSectionDTO> offeringDetailsList = new ArrayList<>();
                    ApiOfferingSectionDTO offeringSectionDTO = new ApiOfferingSectionDTO();
                    offeringSectionDTO.enrollmentCap = offering.getEnrolmentCapacity();
                    offeringSectionDTO.enrollmentTotal = offering.getEnrolmentTotal();
                    offeringSectionDTO.type = offering.getComponentCode();
                    offeringDetailsList.add(offeringSectionDTO);
                    return offeringDetailsList;
                }
            }
        }
        return null;
    }

    private CourseOffering findCourseOfferingById(Course course, int offeringId) {
        for (CourseOffering offering : course.getAllCourseOfferings()) {
            if (offering.getCourseOfferingId() == offeringId) {
                return offering;
            }
        }
        return null;
    }
    private Department findDepartmentById(int deptId) {
        for (Department department : departments) {
            if (department.getDepartmentId() == deptId) {
                return department;
            }
        }
        return null;
    }
    private Course findCourseById(Department department, int courseId) {
        for (Course course : department.getCourses()) {
            if (course.getCourseId() == courseId) {
                return course;
            }
        }
        return null;
    }
    private List<ApiDepartmentDTO> departmentsToDto(){
        List<ApiDepartmentDTO> departmentDTOS = new ArrayList<>();
        for(Department department : departments){
            ApiDepartmentDTO departmentDTO = new ApiDepartmentDTO();
            departmentDTO.name = department.getDepartmentName();
            departmentDTO.deptId = department.getDepartmentId();
            departmentDTOS.add(departmentDTO);
        }
        return departmentDTOS;
    }
    private List<ApiCourseDTO> coursesToDto(List<Course> courses){
        List<ApiCourseDTO> coursesDTO = new ArrayList<>();
        for(Course course : courses){
            ApiCourseDTO courseDTO = new ApiCourseDTO();
            courseDTO.courseId = course.getCourseId();
            courseDTO.catalogNumber = course.getCatalogNumber();
            coursesDTO.add(courseDTO);
        }
        return coursesDTO;
    }
    private List<ApiCourseOfferingDTO> courseOfferingToDTOS(List<CourseOffering> courseOfferings){
        List<ApiCourseOfferingDTO> courseOfferingDTOS = new ArrayList<>();
        for(CourseOffering courseOffering : courseOfferings){
            ApiCourseOfferingDTO courseOfferingDTO = new ApiCourseOfferingDTO();
            courseOfferingDTO.courseOfferingId = courseOffering.getCourseOfferingId();
            courseOfferingDTO.instructors = courseOffering.getInstructors();
            courseOfferingDTO.location = courseOffering.getLocation();
            courseOfferingDTO.term  = (courseOffering.getSemester()).getTerm();
            courseOfferingDTO.year = (courseOffering.getSemester()).getYear();
            courseOfferingDTO.semesterCode = courseOffering.getSemesterCode();
            courseOfferingDTOS.add(courseOfferingDTO);
        }
        return courseOfferingDTOS;
    }

    public void OfferingDataDTOtoModel(ApiOfferingDataDTO offeringDTO){
        CourseOffering courseOffering = new CourseOffering(offeringDTO.semester, offeringDTO.location, offeringDTO.enrollmentCap,
                offeringDTO.enrollmentTotal, offeringDTO.instructor, offeringDTO.component);
        addCourse(offeringDTO.subjectName, offeringDTO.catalogNumber, courseOffering);
    }

}