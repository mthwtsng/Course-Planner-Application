package ca.courseplanner;

import ca.courseplanner.model.CourseOffering;
import ca.courseplanner.service.CoursePlannerService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Responsible for loading course data from CSV file and populates Service class
 * with data
 */
@Component
public class CourseDataLoaderRunner implements CommandLineRunner {

    private static final String CSV_FILE_PATH = "data/course_data_2018.csv";
    private final CoursePlannerService coursePlannerService;
    public CourseDataLoaderRunner(CoursePlannerService coursePlannerService) {
        this.coursePlannerService = coursePlannerService;
    }

    @Override
    public void run(String... args) throws Exception {
        File file = new File(CSV_FILE_PATH);
        try {
            Scanner scanner = new Scanner(file);
            if (scanner.hasNextLine()) {
                scanner.nextLine();
            }
            while (scanner.hasNextLine()) {
                String csvLine = scanner.nextLine();
                processCSVLine(csvLine);
            }
            coursePlannerService.sortCourses();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void processCSVLine(String csvLine) {
        List<String> attributes = parseCSVLine(csvLine);
        String semester = attributes.get(0);
        String subject = attributes.get(1);
        String catalogNumber = attributes.get(2);
        String location = attributes.get(3);
        int enrolmentCapacity = Integer.parseInt(attributes.get(4));
        int enrolmentTotal = Integer.parseInt(attributes.get(5));
        String instructors = "";
        if(!(attributes.get(6).equals("(null)") || attributes.get(6).equals("<null>"))) {
            instructors = attributes.get(6);
        }
        String componentCode = attributes.get(7);

        CourseOffering courseOffering = new CourseOffering(semester, location, enrolmentCapacity,
                enrolmentTotal, instructors, componentCode);
        coursePlannerService.addCourse(subject, catalogNumber, courseOffering);
    }

    private List<String> parseCSVLine(String csvLine) {
        List<String> attributes = new ArrayList<>();
        StringBuilder processedString = new StringBuilder();
        boolean betweenQuotations = false;
        for (char character : csvLine.toCharArray()) {
            if (character == '"') {
                betweenQuotations = !betweenQuotations;
            } else if (character == ',' && !betweenQuotations) {
                attributes.add(processedString.toString().trim());
                processedString.setLength(0);
            } else {
                processedString.append(character);
            }
        }
        attributes.add(processedString.toString().trim());

        return attributes;
    }
}
