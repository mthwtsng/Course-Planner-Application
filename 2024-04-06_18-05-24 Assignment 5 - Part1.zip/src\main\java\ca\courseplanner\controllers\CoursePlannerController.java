package ca.courseplanner.controllers;

import ca.courseplanner.dto.*;
import ca.courseplanner.model.Course;
import ca.courseplanner.model.Department;
import ca.courseplanner.service.CoursePlannerService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controller class to handle HTTP requests for course planner
 */

@RestController
@RequestMapping("/api")
public class CoursePlannerController {

    CoursePlannerService coursePlannerService = new CoursePlannerService();

    public CoursePlannerController(CoursePlannerService coursePlannerService) {
        this.coursePlannerService = coursePlannerService;
    }

    @GetMapping
    public List<Department> getAllCourses() {
        return coursePlannerService.getAllDepartments();
    }

    @GetMapping("/about")
    public ApiAboutDTO getAboutInfo() {
        String appName = "SFU COURSE PLANNER";
        String authorName = "MATTHEW TSENG";
        return new ApiAboutDTO(appName, authorName);

    }

    @GetMapping("/dump-model")
    public void dumpModel() {
        coursePlannerService.dumpModel();
    }

    @GetMapping("/departments")
    public List<ApiDepartmentDTO> getDepartments() {
        return coursePlannerService.getAllDepartmentsAsDTO();
    }

    @GetMapping("/departments/{deptId}/courses")
    public List<ApiCourseDTO> getCoursesByDepartment(@PathVariable int deptId) {
        return coursePlannerService.getCoursesByDepartment(deptId);
    }

    @GetMapping("/departments/{deptId}/courses/{courseId}/offerings")
    public List<ApiCourseOfferingDTO> getCourseOfferings(@PathVariable int deptId, @PathVariable int courseId) {
        return coursePlannerService.getCourseOfferings(deptId, courseId);
    }

    @GetMapping("/departments/{deptId}/courses/{courseId}/offerings/{offeringId}")
    public List<ApiOfferingSectionDTO> getOfferingDetails(
            @PathVariable int deptId,
            @PathVariable int courseId,
            @PathVariable int offeringId) {
        return coursePlannerService.getOfferingDetails(deptId, courseId, offeringId);
    }

    @GetMapping("/stats/students-per-semester")
    public List<Course> getStudentsPerSemester() {
        return null;
    }

    @GetMapping("/watchers")
    public void getWatchers() {

    }

    @PostMapping("/addoffering")
    public void addCourseOffering(@RequestBody ApiOfferingDataDTO newCourseOffering) {
        coursePlannerService.OfferingDataDTOtoModel(newCourseOffering);
    }
}

