package ca.courseplanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoursePlannerApplication {

    public static void main(String[] args) {
        SpringApplication.run(CoursePlannerApplication.class, args);
    }
}
