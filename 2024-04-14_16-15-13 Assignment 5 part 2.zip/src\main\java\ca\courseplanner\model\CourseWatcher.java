package ca.courseplanner.model;

public interface CourseWatcher {
    void newEvent(String event);
}
