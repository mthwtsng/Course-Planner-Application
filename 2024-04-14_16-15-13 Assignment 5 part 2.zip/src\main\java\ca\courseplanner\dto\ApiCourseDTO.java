package ca.courseplanner.dto;

public class ApiCourseDTO {
    public long courseId;
    public String catalogNumber;
}
