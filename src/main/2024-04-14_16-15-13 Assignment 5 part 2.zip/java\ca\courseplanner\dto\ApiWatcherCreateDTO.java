package ca.courseplanner.dto;

public final class ApiWatcherCreateDTO {
    public long deptId;
    public long courseId;
}
