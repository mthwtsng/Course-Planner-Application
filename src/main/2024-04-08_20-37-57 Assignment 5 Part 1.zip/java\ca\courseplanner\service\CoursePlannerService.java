package ca.courseplanner.service;

import ca.courseplanner.dto.*;
import ca.courseplanner.model.*;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Service class to handle course planning related logic and operations
 * Manages Departments, Courses, CourseOfferings and SectionOfferings
 * Provides method
 */

@Service
public class CoursePlannerService {
    private final List<Department> departments = new ArrayList<>();
    private final List<Watcher> watchers = new ArrayList<>();

    public void addCourseData(OfferingData offeringData) {
        String subject = offeringData.getSubject();
        String catalogNumber = offeringData.getCatalogNumber();
        long semesterCode = offeringData.getSemesterCode();
        String location = offeringData.getLocation();
        String instructors = offeringData.getInstructors();
        String componentCode = offeringData.getComponentCode();
        int enrollmentCap = offeringData.getEnrolmentCapacity();
        int enrollmentTotal = offeringData.getEnrolmentTotal();

        Department department = findOrCreateDepartment(subject);

        Course course = findOrCreateCourse(department, subject, catalogNumber);

        CourseOffering courseOffering = new CourseOffering(semesterCode, location, instructors);
        OfferingSection offeringSection = new OfferingSection(componentCode, enrollmentCap, enrollmentTotal);
        addOfferingToCourse(course, courseOffering, offeringSection);
        // notifyWatchers(offeringData, course);
    }

    private Department findOrCreateDepartment(String subject) {
        Department department = findDepartmentByName(subject);
        if (department == null) {
            department = new Department(subject);
            departments.add(department);
        }
        return department;
    }

    private Course findOrCreateCourse(Department department, String subject, String catalogNumber) {
        Course existingCourse = department.findCourseBySubjectAndCatalogNumber(subject, catalogNumber);
        if (existingCourse == null) {
            Course newCourse = new Course(subject, catalogNumber);
            department.addCourse(newCourse);
            return newCourse;
        }
        return existingCourse;
    }


    private void addOfferingToCourse(Course course, CourseOffering courseOffering, OfferingSection offeringSection) {
        CourseOffering existingOffering = course.findSameCourseOffering(courseOffering);
        if (existingOffering != null) {
            updateOfferingSections(existingOffering, offeringSection);
        } else {
            course.addCourseOffering(courseOffering);
            updateOfferingSections(courseOffering, offeringSection);
        }
    }

    private void updateOfferingSections(CourseOffering courseOffering, OfferingSection offeringSection) {
        OfferingSection existingSection = courseOffering.getOfferingSectionByType(offeringSection.getType());
        if (existingSection != null) {
            existingSection.setEnrollmentCapacity(existingSection.getEnrollmentCapacity() + offeringSection.getEnrollmentCapacity());
            existingSection.setEnrollmentTotal(existingSection.getEnrollmentTotal() + offeringSection.getEnrollmentTotal());
        } else {
            courseOffering.addOfferingSection(offeringSection);
        }
    }

//    private void notifyWatchers(OfferingData offering, Course course) {
//        String component = offering.getComponentCode();
//        String enrollmentNumbers = "("+ offering.getEnrolmentTotal() + "/" + offering.getEnrolmentCapacity() + ")";
//        for (Watcher watcher : watchers) {
//            if ((watcher.getCourse()).equals(course)) {
//                String eventDescription = generateEventDescription(component, enrollmentNumbers,
//                        (offering.getSemester()).getTerm(),(offering.getSemester().getYear()));
//                watcher.addEvent(eventDescription);
//            }
//        }
//    }
//
//    private String generateEventDescription(String component, String enrollmentNumbers, String term, int year) {
//        return "Added section " + component + " with enrollment " + enrollmentNumbers + " to offering " +
//                term + " " + year;
//    }


    public List<Department> getAllDepartments() {
        return departments;
    }
    private Department findDepartmentByName(String name) {
        for (Department department : departments) {
            if (department.getDepartmentName().equals(name)) {
                return department;
            }
        }
        return null;
    }

    public void dumpModel() {
        for (Department department : departments) {
            for (Course course : department.getCourses()) {
                System.out.println(course.getSubject() + " " + course.getCatalogNumber());
                printCourseOfferings(course);
            }
        }
    }

    private void printCourseOfferings(Course course) {
        int i = 0;
        for(CourseOffering courseOffering : course.getAllCourseOfferings()){
            System.out.println("   " + courseOffering.getSemesterCode() + " in " + courseOffering.getLocation() + " by " + courseOffering.getInstructors());
            for(OfferingSection offeringSection : courseOffering.getOfferingSections()){
                printOfferingSection(offeringSection.getType(), offeringSection.getEnrollmentTotal(), offeringSection.getEnrollmentCapacity());
            }
        }
    }

    private void printOfferingSection(String currentType, int totalEnrollment, int totalCapacity) {
        System.out.println("        Type = " + currentType + ", Enrollment = " +
                totalEnrollment + "/" + totalCapacity);
    }


    public List<ApiDepartmentDTO> getAllDepartmentsAsDTO(){
        return departmentsToDto();
    }

    public List<ApiCourseDTO> getCoursesByDepartment(Department department){
        return coursesToDto(department.getCourses());
    }

    public List<ApiCourseOfferingDTO> getCourseOfferings(Course course, int courseId) {
        if (course != null) {
            return courseOfferingToDTOS(course.getAllCourseOfferings());
        }
        return null;
    }

    public CourseOffering findCourseOfferingById(Course course, int offeringId) {
        return course.findCourseOfferingById(offeringId);
    }

    public Course findCourseById(Department department, long courseId) {
        return department.findCourseById(courseId);
    }

    public List<ApiOfferingSectionDTO> getOfferingDetails(Department department, Course course, CourseOffering offering) {
        if (department != null && course != null && offering != null) {
            List<ApiOfferingSectionDTO> offeringDetailsList = new ArrayList<>();
            for (OfferingSection section : offering.getOfferingSections()) {
                ApiOfferingSectionDTO offeringSectionDTO = new ApiOfferingSectionDTO();
                offeringSectionDTO.type = section.getType();
                offeringSectionDTO.enrollmentCap = section.getEnrollmentCapacity();
                offeringSectionDTO.enrollmentTotal = section.getEnrollmentTotal();
                offeringDetailsList.add(offeringSectionDTO);
            }
            return offeringDetailsList;
        }
        return null;
    }

    public Department findDepartmentById(long deptId) {
        for (Department department : departments) {
            if (department.getDepartmentId() == deptId) {
                return department;
            }
        }
        return null;
    }

    public void createNewWatcher(long deptId, long courseId) {
        Department department = findDepartmentById(deptId);
        Course course = department.findCourseById(courseId);
        Watcher newWatcher = new Watcher(department, course, new ArrayList<>());
        watchers.add(newWatcher);
    }

    public List<ApiWatcherDTO> getAllWatchers() {
        List<ApiWatcherDTO> apiWatcherDTOS = new ArrayList<>();
        for(Watcher watcher : watchers){
            ApiWatcherDTO apiWatcherDTO = new ApiWatcherDTO();
            apiWatcherDTO.course = coursesToDto(watcher.getCourse());
            apiWatcherDTO.department = departmentToDto(watcher.getDepartment());
            apiWatcherDTO.id = watcher.getId();
            apiWatcherDTO.events = watcher.getEvents();
            apiWatcherDTOS.add(apiWatcherDTO);
        }
        return apiWatcherDTOS;
    }

    public List<String> getEventsForWatcher(int watcherId) {
        for (Watcher watcher : watchers) {
            if (watcher.getId() == watcherId) {
                return watcher.getEvents();
            }
        }
        return null;
    }

    public void deleteWatcher(int watcherId){
        watchers.removeIf(watcher -> watcher.getId() == watcherId);
    }

    private List<ApiDepartmentDTO> departmentsToDto(){
        List<ApiDepartmentDTO> departmentDTOS = new ArrayList<>();
        for(Department department : departments){
            ApiDepartmentDTO departmentDTO = new ApiDepartmentDTO();
            departmentDTO.name = department.getDepartmentName();
            departmentDTO.deptId = department.getDepartmentId();
            departmentDTOS.add(departmentDTO);
        }
        return departmentDTOS;
    }

    private ApiDepartmentDTO departmentToDto(Department department){
        ApiDepartmentDTO departmentDTO = new ApiDepartmentDTO();
        departmentDTO.name = department.getDepartmentName();
        departmentDTO.deptId = department.getDepartmentId();
        return departmentDTO;
    }

    private ApiCourseDTO coursesToDto(Course course){
        ApiCourseDTO courseDTO = new ApiCourseDTO();
        courseDTO.courseId = course.getCourseId();
        courseDTO.catalogNumber = course.getCatalogNumber();
        return courseDTO;
    }
    private List<ApiCourseDTO> coursesToDto(List<Course> courses){
        List<ApiCourseDTO> coursesDTO = new ArrayList<>();
        for(Course course : courses){
            ApiCourseDTO courseDTO = new ApiCourseDTO();
            courseDTO.courseId = course.getCourseId();
            courseDTO.catalogNumber = course.getCatalogNumber();
            coursesDTO.add(courseDTO);
        }
        return coursesDTO;
    }
    private List<ApiCourseOfferingDTO> courseOfferingToDTOS(List<CourseOffering> courseOfferings){
        List<ApiCourseOfferingDTO> courseOfferingDTOS = new ArrayList<>();
        for(CourseOffering courseOffering : courseOfferings){
            ApiCourseOfferingDTO courseOfferingDTO = new ApiCourseOfferingDTO();
            courseOfferingDTO.courseOfferingId = courseOffering.getCourseOfferingId();
            courseOfferingDTO.instructors = courseOffering.getInstructors();
            courseOfferingDTO.location = courseOffering.getLocation();
            courseOfferingDTO.term  = (courseOffering.getSemester()).getTerm();
            courseOfferingDTO.year = (courseOffering.getSemester()).getYear();
            courseOfferingDTO.semesterCode = courseOffering.getSemesterCode();
            courseOfferingDTOS.add(courseOfferingDTO);
        }
        return courseOfferingDTOS;
    }

    public void OfferingDataDTOtoModel(ApiOfferingDataDTO offeringDTO) {
        OfferingData offeringData = new OfferingData(
                offeringDTO.subjectName,
                offeringDTO.catalogNumber,
                offeringDTO.semester,
                offeringDTO.location,
                offeringDTO.enrollmentCap,
                offeringDTO.enrollmentTotal,
                offeringDTO.instructor,
                offeringDTO.component
        );
        addCourseData(offeringData);
    }
}