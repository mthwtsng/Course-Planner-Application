package ca.courseplanner.controllers;

import ca.courseplanner.dto.*;
import ca.courseplanner.model.Course;
import ca.courseplanner.model.CourseOffering;
import ca.courseplanner.model.Department;
import ca.courseplanner.service.CoursePlannerService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controller class to handle HTTP requests for course planner
 */

@RestController
@RequestMapping("/api")
public class CoursePlannerController {

    CoursePlannerService coursePlannerService = new CoursePlannerService();

    public CoursePlannerController(CoursePlannerService coursePlannerService) {
        this.coursePlannerService = coursePlannerService;
    }

    @GetMapping
    public List<Department> getAllCourses() {
        return coursePlannerService.getAllDepartments();
    }

    @GetMapping("/about")
    public ApiAboutDTO getAboutInfo() {
        String appName = "SFU COURSE PLANNER";
        String authorName = "MATTHEW TSENG";
        return new ApiAboutDTO(appName, authorName);

    }

    @GetMapping("/dump-model")
    public void dumpModel() {
        coursePlannerService.dumpModel();
    }

    @GetMapping("/departments")
    public List<ApiDepartmentDTO> getDepartments() {
        return coursePlannerService.getAllDepartmentsAsDTO();
    }

    @GetMapping("/departments/{deptId}/courses")
    public ResponseEntity<List<ApiCourseDTO>> getCoursesByDepartment(@PathVariable int deptId) {
        Department department = coursePlannerService.findDepartmentById(deptId);
        if (department == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
        List<ApiCourseDTO> courses = coursePlannerService.getCoursesByDepartment(department);
        return ResponseEntity.ok(courses);
    }

    @GetMapping("/departments/{deptId}/courses/{courseId}/offerings")
    public ResponseEntity<List<ApiCourseOfferingDTO>> getCourseOfferings(@PathVariable int deptId, @PathVariable int courseId) {
        Department department = coursePlannerService.findDepartmentById(deptId);
        if (department == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
        Course course = coursePlannerService.findCourseById(department, courseId);
        if (course == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
        List<ApiCourseOfferingDTO> courseOfferings = coursePlannerService.getCourseOfferings(course, courseId);
        return ResponseEntity.ok(courseOfferings);
    }

    @GetMapping("/departments/{deptId}/courses/{courseId}/offerings/{offeringId}")
    public ResponseEntity<List<ApiOfferingSectionDTO>> getOfferingDetails(
            @PathVariable int deptId,
            @PathVariable int courseId,
            @PathVariable int offeringId) {
        Department department = coursePlannerService.findDepartmentById(deptId);
        if (department == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
        Course course = coursePlannerService.findCourseById(department, courseId);
        if (course == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
        CourseOffering offering = coursePlannerService.findCourseOfferingById(course, offeringId);
        if (offering == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
        List<ApiOfferingSectionDTO> offeringDetails = coursePlannerService.getOfferingDetails(department, course, offering);
        return ResponseEntity.ok(offeringDetails);
    }

    @PostMapping("/addoffering")
    public ResponseEntity<String> addCourseOffering(@RequestBody ApiOfferingDataDTO newCourseOffering) {
        try{
            coursePlannerService.OfferingDataDTOtoModel(newCourseOffering);
            return ResponseEntity.status(HttpStatus.CREATED).body("New section added");
        } catch(Exception e){
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed");
        }
    }

    @PostMapping("/watchers")
    public ResponseEntity<String> createWatcher(@RequestBody ApiWatcherCreateDTO watcherCreate) {
        try {
            coursePlannerService.createNewWatcher(watcherCreate.deptId, watcherCreate.courseId);
            return ResponseEntity.status(HttpStatus.CREATED).body("Watcher created successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to create watcher");
        }
    }
    @GetMapping("/watchers")
    public List<ApiWatcherDTO> getAllWatchers() {
        return coursePlannerService.getAllWatchers();
    }

    @GetMapping("/watchers/{watcherId}")
    public ResponseEntity<List<String>> getEventsForWatcher(@PathVariable int watcherId) {
        List<String> events = coursePlannerService.getEventsForWatcher(watcherId);
        if (events != null) {
            return ResponseEntity.ok(events);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/watchers/{watcherId}")
    public ResponseEntity<Void> deleteWatcher(@PathVariable int watcherId) {
        coursePlannerService.deleteWatcher(watcherId);
        return ResponseEntity.noContent().build();
    }

}

