package ca.courseplanner.dto;

public class ApiGraphDataPointDTO {
    public long semesterCode;
    public long totalCoursesTaken;
}
