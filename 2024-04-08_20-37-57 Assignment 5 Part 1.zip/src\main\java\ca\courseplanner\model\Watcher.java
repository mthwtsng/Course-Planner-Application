package ca.courseplanner.model;

import java.util.List;

/**
 * Model Class used to represent a watcher that monitors events related to
 * offering sections
 * Tracks when new offering sections of the department + course is made
 */

public class Watcher{
    private int id;
    private Department department;
    private Course course;
    private List<String> events;
    private static int nextId = 1;

    public Watcher(Department department, Course course, List<String> events){
        this.department = department;
        this.course = course;
        this.events = events;
        this.id = nextId++;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

    public List<String> getEvents() {
        return events;
    }

    public void setEvents(List<String> events) {
        this.events = events;
    }
    public void addEvent(String event){
        events.add(event);
    }

    public static int getNextId() {
        return nextId;
    }

    public static void setNextId(int nextId) {
        Watcher.nextId = nextId;
    }


}
